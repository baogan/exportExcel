create
    definer = root@`%` procedure dome2(IN ageId varchar(32))
begin 
declare		  ORDER_NOS  							VARCHAR(225); 
DECLARE				 i 									INT DEFAULT TRUE;
declare		  ageId  									VARCHAR(32);  
declare		  ORDER_count 						INT;
declare			AGE_IDm 		  						VARCHAR(32); 
declare     AGE_ID                  VARCHAR(32);
declare			AGE_NAME    						VARCHAR(32); 
declare			RTS         						VARCHAR(32); 
declare			AGE_COST	  						INT; 
declare			LOWER_COST 							INT; 
declare			AGE_PROFIT_VALUE				INT; 
declare			R_AGE_COST							INT; 
declare			R_LOWER_COST 						INT; 
declare			R_AGE_PROFIT_VALUE 			INT; 
declare     MCHT_NAMEm 							VARCHAR(32);
declare     MCHT_IDm    							VARCHAR(12);
declare     MESSAGE_IDm  						VARCHAR(225);
declare			APP_TIMEm   							VARCHAR(20);
declare			ORDER_NOm   							VARCHAR(64);
declare			AMOUNT_PAIDm  						DOUBLE(19,5);
declare 		PAY_TIMEm   							VARCHAR(14);
declare			RETURN_STATUSm 					VARCHAR(10);
declare     VALIDATION_SERVICE_FEEm	VARCHAR(10);
declare			CUSTOMS_SERVICE_FEEm 		VARCHAR(10);
declare 		PROFIT_STATEm 						VARCHAR(10); 
declare      AGE_IDf                    VARCHAR(10);
declare      PAR_IDf                    VARCHAR(10);
declare      AGE_NAMEf                  VARCHAR(10);
declare      TRADE_NAMEf                VARCHAR(10);
declare      SINGLE_COSTf               VARCHAR(10);
declare      BILLING_METHODf            VARCHAR(10);
declare      FEEf                       VARCHAR(10);
declare      FEE_MINf                   VARCHAR(10);
declare      FEE_MAXf                   VARCHAR(10);
 DECLARE done INT DEFAULT FALSE;     
DECLARE donef INT DEFAULT FALSE;      

	DECLARE orderp CURSOR FOR   
						select AGE_ID,MCHT_NAME,MCHT_ID,MESSAGE_ID,
									 APP_TIME,ORDER_NO,AMOUNT_PAID,PAY_TIME,RETURN_STATUS,
									 VALIDATION_SERVICE_FEE,CUSTOMS_SERVICE_FEE,PROFIT_STATE
								 	from	v_order_record   limit 3;  
					DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; 
				   SET 	ORDER_count =0;
					set ORDER_NOS ='';
				OPEN orderp; 
						orderp_loop: LOOP
							FETCH orderp into AGE_IDm,MCHT_NAMEm,MCHT_IDm,MESSAGE_IDm,APP_TIMEm,ORDER_NOm,AMOUNT_PAIDm, PAY_TIMEm,RETURN_STATUSm,VALIDATION_SERVICE_FEEm,CUSTOMS_SERVICE_FEEm,PROFIT_STATEm;
							IF done THEN
								LEAVE orderp_loop;
							END IF;
											  		SET 	ORDER_count =ORDER_count+1; 
								set ORDER_NOS=CONCAT(ORDER_NOS,APP_TIMEm,',');
									WHILE i DO
										if AGE_COST=4 THEN
													set	i =false;
										end if;
												SET 	AGE_COST =AGE_COST+1; 
												SET LOWER_COST =LOWER_COST+1;
							  END WHILE;
							
									
						END LOOP orderp_loop;   
				CLOSE	orderp;


select ORDER_count,AGE_COST,LOWER_COST; 
END;

