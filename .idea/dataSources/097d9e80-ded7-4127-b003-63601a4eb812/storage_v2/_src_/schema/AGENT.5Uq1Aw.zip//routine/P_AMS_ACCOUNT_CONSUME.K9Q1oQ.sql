create
    definer = root@`%` procedure P_AMS_ACCOUNT_CONSUME(IN start_time varchar(16))
BEGIN 																			
DECLARE				 i 									INT DEFAULT TRUE; 
DECLARE       AGE_NAME 	VARCHAR(32);
DECLARE       DLSFR 		INT;
DECLARE       DLSCB 		INT;
DECLARE       ageId 		VARCHAR(32);  
DECLARE       TDFR 			INT; 
DECLARE       ORDER_count INT;
DECLARE       XJCB  		INT;
DECLARE       XJFL   		INT;
DECLARE       B_METHOD  INT;
DECLARE       TDLSCB 		INT;
DECLARE       TDLSFR 		INT;
DECLARE       TXJCB 		INT;
DECLARE 			_ORDER_NO  VARCHAR(32);
DECLARE				_MCHT_ID   VARCHAR(10);
DECLARE				_CUSTOM_ID VARCHAR(12);
DECLARE				_PAY_DATE 	VARCHAR(8);
DECLARE				_PAY_TIME	VARCHAR(8);
DECLARE				_ORDER_FEE_VALUE VARCHAR(12);
DECLARE				_PROFIT_STATE  CHAR(2); 
DECLARE				_MCHT_NAME     VARCHAR(32);
DECLARE				_MCHT_MAX_FEE_VALUE decimal(10,4);
DECLARE				_MCHT_MIN_FEE_VALUE decimal(10,4);
DECLARE				_MCHT_FEE 					 decimal(10,4);
DECLARE				_BILLING_METHOD     CHAR(2); 
DECLARE				_SINGLE_COST				 decimal(10,4); 
DECLARE 			_AGE_ID            VARCHAR(32);
DECLARE				_PAY_AMT 					VARCHAR(12);			
declare        AGE_IDf                    VARCHAR(10);
declare        PAR_IDf                    VARCHAR(10);
declare        AGE_NAMEf                  VARCHAR(10);
declare        TRADE_NAMEf                VARCHAR(10);
declare        SINGLE_COSTf               VARCHAR(10);
declare        BILLING_METHODf            VARCHAR(10);
declare        FEEf                       VARCHAR(10);
declare        FEE_MINf                   VARCHAR(10);
declare        FEE_MAXf                   VARCHAR(10);
declare  			 _AGE_IDf										VARCHAR(10);

DECLARE gly VARCHAR(10) DEFAULT '0000000000';      
DECLARE yjdls VARCHAR(10) DEFAULT '0000000001';      
DECLARE done INT DEFAULT FALSE;     
DECLARE edone INT DEFAULT FALSE;      
	
	DECLARE orderp CURSOR FOR   
						select AGE_ID,MCHT_NAME,ORDER_NO,
						 MCHT_ID,CUSTOM_ID,PAY_DATE, PAY_TIME,PAY_AMT,ORDER_FEE_VALUE,PROFIT_STATE,
						 MCHT_MAX_FEE_VALUE,MCHT_MIN_FEE_VALUE,MCHT_FEE,BILLING_METHOD,SINGLE_COST    from v_account_consume where PAY_DATE  = start_time;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
			
		SET ORDER_count =0; 
		SET   ageId  ='';
			OPEN orderp;
			
			loop_a:LOOP 
				
			FETCH orderp into _AGE_ID,_MCHT_NAME,_ORDER_NO,
						 _MCHT_ID,_CUSTOM_ID,_PAY_DATE,_PAY_TIME,_PAY_AMT,_ORDER_FEE_VALUE,_PROFIT_STATE,
						 _MCHT_MAX_FEE_VALUE,_MCHT_MIN_FEE_VALUE,_MCHT_FEE,_BILLING_METHOD,_SINGLE_COST;
				
				if done=1 then
            leave loop_a;
        end if;    
							SET ORDER_count=ORDER_count+1;
							SET	ageId  =_AGE_ID;   
							SET B_METHOD  =_BILLING_METHOD; 
							SET XJFL  =_MCHT_FEE;
						 
							if B_METHOD ='0' THEN  
							SET	XJCB  =IFNULL(_ORDER_FEE_VALUE,0); 
							END if; 
							if B_METHOD ='1' THEN  
							SET	XJCB =IFNULL(_SINGLE_COST,0);  
							END if; 
						
						set i=true; 
						WHILE  i   DO  
					  SET edone = 0;
					  BEGIN
				
							DECLARE order_fee CURSOR FOR   select  AGE_ID,PAR_ID,AGE_NAME,TRADE_NAME,SINGLE_COST,BILLING_METHOD,FEE,FEE_MIN,FEE_MAX from v_account_consume_fee where AGE_ID=ageId; 
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET edone = 1;
								OPEN order_fee;
								vfiledataLoop:LOOP 
									FETCH order_fee INTO AGE_IDf,PAR_IDf,AGE_NAMEf,TRADE_NAMEf,SINGLE_COSTf,BILLING_METHODf,FEEf,FEE_MINf,FEE_MAXf;		 
									IF edone = 1 THEN
										LEAVE vfiledataLoop;
									END IF;
								SET ageId  = PAR_IDf; 
								SET _AGE_IDf  = AGE_IDf;
								SET	AGE_NAME  = AGE_NAMEf;
								
									
					
							if B_METHOD ='0' THEN  
							SET	DLSCB  =IFNULL( _PAY_AMT,0)  * IFNULL( FEEf,0)*0.01 ;   
									
									if IFNULL( FEE_MINf,0) > DLSCB THEN   
									SET	DLSCB =IFNULL( FEE_MINf,0);
								  end if; 
								end IF;
							if B_METHOD ='1' THEN  
								SET	DLSCB=IFNULL( SINGLE_COSTf,0); 
							END if; 
							   
								SET	DLSFR =XJCB-DLSCB;
								if ageId  =gly THEN   
										SET i=FALSE;
										SET DLSFR =TDFR;
										SET DLSCB =0;
								 
									end if; 
					   			 SET TDFR =DLSCB; 
					
							if _AGE_IDf  <> yjdls THEN
									if B_METHOD ='0' THEN  
										SET	TDLSCB =round(DLSCB,3);
										SET	TDLSFR =round(DLSFR,3);
										SET	TXJCB =round(XJCB,3);
									END if; 
										if B_METHOD ='1' THEN  
									 SET  TDLSCB =DLSCB*100;
									 SET  TDLSFR =DLSFR*100;
										SET TXJCB =XJCB*100;
										END if; 
							 END if;
							if _AGE_IDf ='0000000001' THEN
									if B_METHOD ='0' THEN  
										SET	TDLSCB =round(DLSCB,4);
										SET	TDLSFR =round(DLSFR,4);
										SET	TXJCB =round(XJCB,4);
									END if; 
										if B_METHOD ='1' THEN  
									 SET  TDLSCB =DLSCB*100;
									 SET  TDLSFR =DLSFR*100;
									 SET  TXJCB =XJCB*100;
										END if; 
							 END if;
						 
					INSERT  INTO AMS_AGE_PROFIT_DETAILED
										(
											ORDER_ID,
											ORDER_PAY_DATE,
											ORDER_PAY_TIME,
											ORDER_TOTAL_PAYMENT,
											MCHT_ID,
											MCHT_NAME,
									   	MCHT_FEE,
											MCHT_MAX_FEE_VALUE,
										  MCHT_MIN_FEE_VALUE,
											MCHT_COST,
											AGE_ID,
											AGE_NAME,
											AGE_FEE,
											AGE_MAX_FEE_VALUE,
										  AGE_MIN_FEE_VALUE,
										  AGE_COST,
											AGE_PROFIT_VALUE,
											CRT_OPR,
											CRT_TIME,
											
								     	PROFIT_TYPE,
										  BILLING_METHOD,
											LOWER_FEE,
											LOWER_COST
										) VALUES (
											_ORDER_NO,
										  _PAY_DATE,
											_PAY_TIME, 
											_PAY_AMT,
											_MCHT_ID,
											_MCHT_NAME,
										  _MCHT_FEE,
											_MCHT_MAX_FEE_VALUE,
											_MCHT_MIN_FEE_VALUE,
											_PAY_AMT,
											AGE_ID,
											AGE_NAME,
											 FEEf,
											 FEE_MAXf,
												FEE_MINf,
										  TDLSCB,
											TDLSFR,
											'0000000001',
											DATE_FORMAT( NOW(), '%Y%m%d%H%i%S' ) ,
											
											'03',
											0,
											XJFL,TXJCB
										);   
										SET XJFL = FEEf;

								if B_METHOD ='0' THEN  
								SET	 	XJCB  =DLSCB; 
								END if; 

								if B_METHOD ='1' THEN  
								SET	   XJCB  =DLSCB; 
								END if;  

								END LOOP vfiledataLoop; 
									CLOSE order_fee; 
								END;

						END WHILE; 
					update AMS_ACCOUNT_CONSUME_INF set  PROFIT_STATE='0'  where ORDER_NO=_ORDER_NO; 
				end loop loop_a; 
			CLOSE orderp; 
SELECT ORDER_count;
END;

