create
    definer = root@`%` procedure AGE_PROFIT_COLLECT_PROCEDURE(IN months varchar(8))
BEGIN 
			 DECLARE       ORDER_count               INT;
			 DECLARE      _AGE_NAME 							   VARCHAR(200);	
			 DECLARE      _MCHT_ORDER_COUNT			     VARCHAR(10);
			 DECLARE      _AGE_ID								     VARCHAR(10);
			 DECLARE      _PROFIT_TYPE						   VARCHAR(4);			
			 DECLARE      _PRTOTAL								   VARCHAR(20);
			 DECLARE      _PAYTOTAL							     VARCHAR(20); 
		 	 DECLARE			AGE_ID_                    VARCHAR(10); 
			 DECLARE			AGE_NAME_                  VARCHAR(30);
			 DECLARE			AGE_PROFIT_VALUE_COLLECT_  VARCHAR(20);
			 DECLARE			MCHT_ORDER_COUNT_          VARCHAR(20);
			 DECLARE			ORDER_AMOUNT_COLLECT_      VARCHAR(20);
			 DECLARE			CRT_OPR_                   VARCHAR(10);
			 DECLARE			UPD_TIME_                  VARCHAR(14);
			 DECLARE			CRT_TIME_									 VARCHAR(14);
			 DECLARE      DAYBAGEN                   VARCHAR(14);
			 DECLARE      DAYEND 										 VARCHAR(14); 
		DECLARE done INT DEFAULT FALSE;     

		DECLARE orderp CURSOR FOR  
		select  DATE_FORMAT( date_add(curdate(), interval - day(curdate()) + 1 day), '%Y%m%d') dayBegin, DATE_FORMAT( last_day(curdate()), '%Y%m%d' ) dayEnd,
					T1.AGE_NAME,  T2.MCHT_ORDER_COUNT, 	T2.AGE_ID, T2.PROFIT_TYPE, T2.PRTOTAL, T2.PAYTOTAL
					from AMS_AGE_BASE_INF T1 
					RIGHT JOIN (select  COUNT(1) as MCHT_ORDER_COUNT, AGE_ID,PROFIT_TYPE,sum(AGE_PROFIT_VALUE)  as PrTotal,sum(ORDER_TOTAL_PAYMENT )  as payTotal
					from AMS_AGE_PROFIT_DETAILED  
					where  ORDER_PAY_DATE  =  months COLLATE utf8_unicode_ci  and   COLLECT_STATE='1'  GROUP BY AGE_ID,PROFIT_TYPE ) T2 on T1.AGE_ID=T2.AGE_ID;
				DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	SET ORDER_count = 0;
	delete from AMS_AGE_PROFIT_COLLECT where COLLECT_DATE=months COLLATE utf8_unicode_ci;
	OPEN orderp;
	loop_a:LOOP 
				
			FETCH orderp into  DAYBAGEN,DAYEND,_AGE_NAME,_MCHT_ORDER_COUNT,_AGE_ID,_PROFIT_TYPE,_PRTOTAL,_PAYTOTAL;
				
				if done=1 then
            leave loop_a;
        end if;    
			
						SET ORDER_count =  ORDER_count+1;          	    
						SET AGE_ID_  =_AGE_ID;                      
						SET AGE_NAME_  =_AGE_NAME;                    
						SET AGE_PROFIT_VALUE_COLLECT_ = _PRTOTAL;      
						SET MCHT_ORDER_COUNT_         = _MCHT_ORDER_COUNT;     
						SET ORDER_AMOUNT_COLLECT_     = _PAYTOTAL;     
						SET CRT_OPR_                  ='0000000001';     
						SET UPD_TIME_                 =DATE_FORMAT( NOW(), '%Y%m%d%H%i%S' ) ;     
						SET CRT_TIME_								  =months COLLATE utf8_unicode_ci;
							

					 INSERT  INTO AMS_AGE_PROFIT_COLLECT (
          AGE_ID,
          AGE_NAME,
          AGE_PROFIT_VALUE_COLLECT,
          MCHT_ORDER_COUNT,
          ORDER_AMOUNT_COLLECT,
          CRT_OPR,
          CRT_TIME,
					UPD_TIME,
				  COLLECT_START_DATE,
				  COLLECT_END_DATE,
					COLLECT_DATE,
					PROFIT_TYPE
        )  VALUES  (
          AGE_ID_,
          AGE_NAME_,
          AGE_PROFIT_VALUE_COLLECT_,
          MCHT_ORDER_COUNT_,
          ORDER_AMOUNT_COLLECT_,
          CRT_OPR_,
          CRT_TIME_,
					UPD_TIME_,
					DAYBAGEN,
				  DAYEND,
				  months,
				_PROFIT_TYPE
        );
      UPDATE AMS_AGE_PROFIT_DETAILED A1   SET A1.COLLECT_STATE   = '0' WHERE A1.AGE_ID  =AGE_ID AND A1.COLLECT_STATE      = '1'  AND SUBSTR(A1.CRT_TIME, 1, 6) = months ;
 
		END LOOP loop_a;
CLOSE orderp; 
END;

