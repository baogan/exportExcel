create definer = root@`%` view v_order_record_fee as
select `a1`.`AGE_ID`         AS `AGE_ID`,
       `a1`.`PAR_ID`         AS `PAR_ID`,
       `a1`.`AGE_NAME`       AS `AGE_NAME`,
       `a2`.`TRADE_NAME`     AS `TRADE_NAME`,
       `a2`.`SINGLE_COST`    AS `single_cost`,
       `a2`.`BILLING_METHOD` AS `billing_method`,
       `a2`.`FEE`            AS `fee`,
       `a2`.`FEE_MIN`        AS `FEE_MIN`,
       `a2`.`FEE_MAX`        AS `FEE_MAX`
from (`AGENT`.`AMS_AGE_BASE_INF` `a1`
         left join `AGENT`.`AMS_AGE_FEE` `a2` on ((`a1`.`AGE_ID` = `a2`.`OPR_ID`)))
where (`a2`.`TRADE_TYPE` = '04');

-- comment on column v_order_record_fee.AGE_ID not supported: 代理商编号ID

-- comment on column v_order_record_fee.PAR_ID not supported: 所属上级代理商

-- comment on column v_order_record_fee.AGE_NAME not supported: 代理商名称

-- comment on column v_order_record_fee.TRADE_NAME not supported: 费率名称 01-汇入 02-汇出 03-账户消费  04-海关推单 041-实名认证

-- comment on column v_order_record_fee.single_cost not supported: 单笔费用

-- comment on column v_order_record_fee.billing_method not supported: 计费方式 0-按费率 1-按单笔 2-单笔费用+费率

-- comment on column v_order_record_fee.fee not supported: 费率(%)

-- comment on column v_order_record_fee.FEE_MIN not supported: 保底值

-- comment on column v_order_record_fee.FEE_MAX not supported: 封顶手续费

