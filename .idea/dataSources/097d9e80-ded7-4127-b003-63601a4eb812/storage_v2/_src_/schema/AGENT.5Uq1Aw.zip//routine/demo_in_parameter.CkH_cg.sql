create
    definer = root@`%` procedure demo_in_parameter()
BEGIN   

DECLARE				 i 									INT DEFAULT TRUE;
declare		  ORDER_count 						INT  DEFAULT TRUE;
declare		  AGE_COST 						INT;
declare		  LOWER_COST 						INT;
declare     ddd      INT;
DECLARE ccc VARCHAR(32);
DECLARE dd VARCHAR(32);
DECLARE ee VARCHAR(32);

declare     a1      INT;
declare     a2      INT;
declare     a3      INT;

DECLARE gly VARCHAR(32) DEFAULT '0000000000';      
set AGE_COST =0; 
SET   LOWER_COST = 0;  
set ccc='0000000000';
set dd='abcd1';
set a1=0;

	WHILE  a1<22   DO   
						set ORDER_count=true;
						set LOWER_COST=0;
			WHILE  ORDER_count   DO  

												set i=true;
												set ddd=0;

												WHILE  i   DO
																		set ddd=ddd+1;
																	IF ddd =2 THEN 
																	set i=false;
																	end if;
																SET 	AGE_COST = AGE_COST+1;  
												END WHILE;
			
											SET   LOWER_COST = LOWER_COST+1; 
											IF LOWER_COST=2 THEN
												set ORDER_count=false;
											end if;
								  END WHILE;
		 
	set a1=a1+1;
  END WHILE;
								if ccc = gly THEN
										set ee='wsnd';
								end if;

					select AGE_COST,LOWER_COST,i,ee,a1;
     END;

