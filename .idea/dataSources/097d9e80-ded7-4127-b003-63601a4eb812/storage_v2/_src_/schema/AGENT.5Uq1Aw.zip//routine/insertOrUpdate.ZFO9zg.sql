create
    definer = root@`%` procedure insertOrUpdate(IN mchtId varchar(10), IN noticeType varchar(12),
                                                IN noticeUrl varchar(255), IN noticeStatus char(2),
                                                IN crtOprId varchar(20), IN recCrtTs varchar(25),
                                                IN updOprId varchar(10), IN recUpdTs varchar(25))
BEGIN
 
DECLARE          _mchtId            VARCHAR(32);
DECLARE          _noticeType            VARCHAR(32);
DECLARE          _noticeUrl            VARCHAR(32);
DECLARE          _noticeStatus					CHAR(2);
DECLARE          _crtOprId            VARCHAR(32);
DECLARE          _recCrtTs            VARCHAR(32);
DECLARE          _updOprId            VARCHAR(32);
DECLARE          _recUpdTs  					 VARCHAR(32);
DECLARE          DATASTATUS						INT;
DECLARE done INT DEFAULT FALSE;     

DECLARE orderp CURSOR FOR   
			select MCHT_ID,NOTICE_TYPE from AMS_ACCOUNT_NOTICE_URL where MCHT_ID=mchtId and NOTICE_TYPE=noticeType LIMIT 1; 
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
SET DATASTATUS=1;
OPEN orderp;
		
		loop_a:LOOP 
			
			FETCH orderp into _mchtId,_noticeType; 
				if done=1 then
            leave loop_a;
        end if; 
				SET	DATASTATUS=0;
					 update AMS_ACCOUNT_NOTICE_URL set 
					 NOTICE_URL = noticeUrl,
					 UPD_OPR_ID = updOprId,
					 REC_UPD_TS =recUpdTs
					 where MCHT_ID =mchtId
					 and NOTICE_TYPE =noticeType;
	END LOOP loop_a; 
CLOSE orderp; 
		IF DATASTATUS =1 THEN
				 insert into AMS_ACCOUNT_NOTICE_URL (MCHT_ID, NOTICE_TYPE, NOTICE_URL, 
         NOTICE_STATUS, CRT_OPR_ID, REC_CRT_TS, 
         UPD_OPR_ID, REC_UPD_TS)
         values (mchtId, noticeType, noticeUrl, 
         noticeStatus,crtOprId, recCrtTs, 
         updOprId, recUpdTs);
		END IF; 
select DATASTATUS;
END;

