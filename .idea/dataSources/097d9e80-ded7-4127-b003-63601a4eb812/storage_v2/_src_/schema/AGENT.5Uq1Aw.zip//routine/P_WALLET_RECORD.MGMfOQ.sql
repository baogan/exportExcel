create
    definer = root@`%` procedure P_WALLET_RECORD(IN start_time varchar(16))
BEGIN

	DECLARE		  i 	 INT DEFAULT TRUE;
	DECLARE   done    INT DEFAULT FALSE;     
	DECLARE   edone   INT DEFAULT FALSE;      
	DECLARE  	T_TYPEa  VARCHAR(4); 
	DECLARE  	AMOUNTa INT;         
	DECLARE  	BILL_IDa VARCHAR(32);
	DECLARE  	AGE_IDa VARCHAR(12); 
	DECLARE  	RECORD_DATEa VARCHAR(32);  
	DECLARE  	RECORD_TIMEa VARCHAR(32); 
	DECLARE  	MCHT_IDa VARCHAR(12);     
	DECLARE  	MCHT_NAMEa VARCHAR(32); 
	DECLARE		ageId     VARCHAR(12);   
	DECLARE		LOWER_COST  INT; 
	DECLARE			AGE_COST	  	INT; 
	DECLARE    PROFIT_TYPE  VARCHAR(4);   
DECLARE      AGE_IDf                    VARCHAR(10);
DECLARE      PAR_IDf                    VARCHAR(10);
DECLARE      AGE_NAMEf                  VARCHAR(32);
DECLARE      TRADE_NAMEf                VARCHAR(10);
DECLARE      SINGLE_COSTf               VARCHAR(10);
DECLARE      BILLING_METHODf            VARCHAR(10);
DECLARE      FEEf                       VARCHAR(10);
DECLARE      FEE_MINf                   VARCHAR(10);
DECLARE      FEE_MAXf                   VARCHAR(10);  
DECLARE			_AGE_IDf 		  					VARCHAR(32);  
DECLARE			RTS         						VARCHAR(32); 
DECLARE			AGE_PROFIT_VALUE				INT; 



	DECLARE orderp CURSOR FOR   
		select  T_TYPE,AMOUNT,BILL_ID,AGE_ID,RECORD_DATE,RECORD_TIME,MCHT_ID,MCHT_NAME  from v_wallet_list where  RECORD_DATE = start_time COLLATE utf8_unicode_ci;   
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
delete from  AMS_AGE_PROFIT_DETAILED where ORDER_PAY_DATE =start_time COLLATE utf8_unicode_ci; 
	
	OPEN orderp;
		
		loop_a:LOOP 
			
				FETCH orderp into T_TYPEa,AMOUNTa,BILL_IDa,AGE_IDa,RECORD_DATEa,RECORD_TIMEa,MCHT_IDa,MCHT_NAMEa ;
						
					if done=1 then
							leave loop_a;
					end if;  
				  SET ageId  =AGE_IDa; 
					SET LOWER_COST  =IFNULL(AMOUNTa,0);
				  SET AGE_COST  =0;					
					if T_TYPEa ='04' then 
						SET PROFIT_TYPE ='04';
					end if;
					if T_TYPEa ='041' then 
						SET PROFIT_TYPE ='05';
					end if; 
						set i=true; 
							WHILE  i   DO  
							SET edone = 0;

							BEGIN
					
							DECLARE order_fee CURSOR FOR   select    AGE_ID,AGE_NAME,PAR_ID,TRADE_NAME,SINGLE_COST,BILLING_METHOD,FEE,FEE_MIN,FEE_MAX from v_order_record_fee where AGE_ID=ageId and  TRADE_NAME=T_TYPEa;   
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET edone = 1;
									OPEN order_fee;
									vfiledataLoop:LOOP 
											FETCH order_fee INTO   AGE_IDf,AGE_NAMEf,PAR_IDf,TRADE_NAMEf,SINGLE_COSTf,BILLING_METHODf,FEEf,FEE_MINf,FEE_MAXf;		 
												IF edone = 1 THEN
													LEAVE vfiledataLoop;
												END IF;	
				
								  SET ageId  = PAR_IDf; 
									SET _AGE_IDf  =  AGE_IDf;
								  if ageId  ='0000000000'  THEN 
										SET		i = FALSE;
								  end if;     
										SET	AGE_COST =IFNULL( SINGLE_COSTf,0)* 100; 
										SET RTS ='04';
										if _AGE_IDf  ='0000000001' THEN  
											SET AGE_COST =0;
										end if;   
										SET AGE_PROFIT_VALUE  =LOWER_COST-AGE_COST; 
								
										INSERT  INTO AMS_AGE_PROFIT_DETAILED (
											ORDER_ID,
											ORDER_PAY_DATE,
											ORDER_PAY_TIME, 
											MCHT_ID,
											MCHT_NAME, 
										  MCHT_COST,
											AGE_ID,
											AGE_NAME, 
										  AGE_COST,
											AGE_PROFIT_VALUE,
											CRT_OPR,
											CRT_TIME, 
								     	PROFIT_TYPE,
										  BILLING_METHOD,
											LOWER_COST,
											COLLECT_STATE
										) VALUES (
											BILL_IDa,
											 RECORD_DATEa,
											RECORD_TIMEa, 
											 MCHT_IDa, 
											 MCHT_NAMEa,
											 AMOUNTa, 
											_AGE_IDf,
											AGE_NAMEf,  
									    AGE_COST,
											AGE_PROFIT_VALUE,
											'0000000001',
											DATE_FORMAT( NOW(), '%Y%m%d%H%i%S' ) , 
											PROFIT_TYPE,
											1,
											LOWER_COST, 
											1
										);  

											SET LOWER_COST  =AGE_COST;
  
									END LOOP vfiledataLoop; 
									CLOSE order_fee; 
							END; 
						 END WHILE;  
 
				END LOOP loop_a; 
	CLOSE orderp;   
END;

