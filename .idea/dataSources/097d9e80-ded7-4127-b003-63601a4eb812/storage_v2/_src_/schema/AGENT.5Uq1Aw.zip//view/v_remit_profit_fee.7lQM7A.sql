create definer = root@`%` view v_remit_profit_fee as
select `a1`.`AGE_ID`        AS `AGE_ID`,
       `a1`.`PAR_ID`        AS `PAR_ID`,
       `a1`.`AGE_NAME`      AS `AGE_NAME`,
       `a2`.`FEE`           AS `AGE_FEE`,
       `a2`.`FEE_MAX`       AS `AGE_MAX_FEE_VALUE`,
       `a2`.`FEE_MIN`       AS `AGE_MIN_FEE_VALUE`,
       `a2`.`CURRENCY`      AS `AGE_FEE_CURRENCY`,
       `a2`.`TELEGRAPH_FEE` AS `TELEGRAPH_FEE`
from (`AGENT`.`AMS_AGE_BASE_INF` `a1`
         left join `AGENT`.`AMS_AGE_FEE` `a2` on ((`a1`.`AGE_ID` = `a2`.`OPR_ID`)))
where (`a2`.`TRADE_TYPE` = 2);

-- comment on column v_remit_profit_fee.AGE_ID not supported: 代理商编号ID

-- comment on column v_remit_profit_fee.PAR_ID not supported: 所属上级代理商

-- comment on column v_remit_profit_fee.AGE_NAME not supported: 代理商名称

-- comment on column v_remit_profit_fee.AGE_FEE not supported: 费率(%)

-- comment on column v_remit_profit_fee.AGE_MAX_FEE_VALUE not supported: 封顶手续费

-- comment on column v_remit_profit_fee.AGE_MIN_FEE_VALUE not supported: 保底值

-- comment on column v_remit_profit_fee.AGE_FEE_CURRENCY not supported: 币种

-- comment on column v_remit_profit_fee.TELEGRAPH_FEE not supported: 电报费(跨境汇入、汇出需要设置)

