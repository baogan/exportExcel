create definer = root@`%` view v_order_record as
select `t2`.`AGE_ID`                 AS `AGE_ID`,
       `t2`.`MCHT_NAME`              AS `MCHT_NAME`,
       `t1`.`MCHT_ID`                AS `MCHT_ID`,
       `t1`.`MESSAGE_ID`             AS `MESSAGE_ID`,
       `t1`.`APP_TIME`               AS `APP_TIME`,
       `t1`.`ORDER_NO`               AS `ORDER_NO`,
       `t1`.`AMOUNT_PAID`            AS `AMOUNT_PAID`,
       `t1`.`PAY_TIME`               AS `PAY_TIME`,
       `t1`.`RETURN_STATUS`          AS `RETURN_STATUS`,
       `t1`.`VALIDATION_SERVICE_FEE` AS `VALIDATION_SERVICE_FEE`,
       `t1`.`CUSTOMS_SERVICE_FEE`    AS `CUSTOMS_SERVICE_FEE`,
       `t1`.`PROFIT_STATE`           AS `PROFIT_STATE`
from (`AGENT`.`AMS_OPR_ORDER_RECORD` `t1`
         left join `AGENT`.`AMS_MCHT_BASE_INF` `t2` on ((`t1`.`MCHT_ID` = `t2`.`MCHT_ID`)))
where ((ifnull(`t1`.`PROFIT_STATE`, 1) = '1') and (`t1`.`RETURN_STATUS` <> '-1') and
       (`t1`.`RETURN_STATUS` <> '-4') and (`t1`.`RETURN_STATUS` <> '-3'));

-- comment on column v_order_record.AGE_ID not supported: 商户所属代理商编号

-- comment on column v_order_record.MCHT_NAME not supported: 企业名称

-- comment on column v_order_record.MCHT_ID not supported: 商户编号

-- comment on column v_order_record.MESSAGE_ID not supported: 报文唯一编号 企业系统生成 36 位报文唯一序号（要求为 guid36 位，英文字母大写）。

-- comment on column v_order_record.APP_TIME not supported: 报送时间

-- comment on column v_order_record.ORDER_NO not supported: 订单编号

-- comment on column v_order_record.AMOUNT_PAID not supported: 支付金额

-- comment on column v_order_record.PAY_TIME not supported: 支付时间

-- comment on column v_order_record.RETURN_STATUS not supported: 操作结果（1-数据中心已接收 2 电子口岸申报中/3 发送海关成功/4 发送海关失败/100 海关退单/120 海关入库）,若小于 0 数字表示处理异常回执。

-- comment on column v_order_record.VALIDATION_SERVICE_FEE not supported: 实名验证费用

-- comment on column v_order_record.CUSTOMS_SERVICE_FEE not supported: 海关推单费用

-- comment on column v_order_record.PROFIT_STATE not supported: 分润状态 0已计算 1未计算

