create
    definer = root@`%` procedure P_AMS_OPR_REMIT_PROFIT(IN start_time varchar(16), IN end_time varchar(16))
BEGIN                    
DECLARE          ORDER_count   INT(16); 
DECLARE          sttime VARCHAR(16);
DECLARE          entime VARCHAR(16); 
DECLARE          ageId VARCHAR(16);
DECLARE          i INT;       
DECLARE          ORDER_TOTAL_PAYMENT    INT;   
DECLARE          AGE_PROFIT_VALUE       INT;   
DECLARE          AGE_COST               INT;  
DECLARE          TAGE_PROFIT_VALUE      INT;   
DECLARE          DLSFR  INT; 
DECLARE          TDFR INT; 
DECLARE          DBF INT;
DECLARE          SHCB INT;
DECLARE          XJFL   INT;
DECLARE          XJCB  INT;
DECLARE          DLSDBF INT;
DECLARE         _MCHT_NO 		VARCHAR(20); 
DECLARE         _TOTAL_SUM	  VARCHAR(20); 	
DECLARE         _REC_CRT_TS		VARCHAR(14); 
DECLARE         _PAYMENT_DEAL_TIME  VARCHAR(20);  
DECLARE         _ORDER_ID		VARCHAR(20);
DECLARE         _ORDER_FEE		VARCHAR(14); 
DECLARE         _AGE_ID			VARCHAR(10);
DECLARE         _Mcht_Name			VARCHAR(32);
DECLARE         _MCHT_MAX_FEE_VALUE 	decimal(10,4);
DECLARE         _MCHT_MIN_FEE_VALUE	decimal(10,4);
DECLARE         _MCHT_FEE			decimal(10,4); 
 
declare      _PAR_ID               VARCHAR(10);
declare      _AGE_NAME             VARCHAR(10);
declare      _AGE_FEE              VARCHAR(10); 
declare      _AGE_MAX_FEE_VALUE    VARCHAR(10);
declare      _AGE_MIN_FEE_VALUE    VARCHAR(10);
declare      _AGE_FEE_CURRENCY     VARCHAR(10);
declare      _TELEGRAPH_FEE        VARCHAR(10); 
 
DECLARE gly VARCHAR(10) DEFAULT '0000000000';      
DECLARE yjdls VARCHAR(10) DEFAULT '0000000001';      
DECLARE done INT DEFAULT FALSE;     
DECLARE edone INT DEFAULT FALSE;      
	
	
	DECLARE orderp CURSOR FOR   
						select  MCHT_NO, TOTAL_SUM,REC_CRT_TS,PAYMENT_DEAL_TIME,ORDER_ID,ORDER_FEE,AGE_ID,Mcht_Name,MCHT_MAX_FEE_VALUE,MCHT_MIN_FEE_VALUE,MCHT_FEE,TELEGRAPH_FEE
							from v_remit_profit where  	REC_CRT_TS    >= start_time  AND  REC_CRT_TS     < end_time;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
			SET ORDER_count =0; 
	
			OPEN orderp;
			
			loop_a:LOOP 
				
			FETCH orderp into _MCHT_NO, _TOTAL_SUM,_REC_CRT_TS,_PAYMENT_DEAL_TIME,_ORDER_ID,_ORDER_FEE,_AGE_ID,_Mcht_Name,_MCHT_MAX_FEE_VALUE,_MCHT_MIN_FEE_VALUE,_MCHT_FEE,_TELEGRAPH_FEE;
				
				if done=1 then
            leave loop_a;
        end if;     
					SET	ageId = _AGE_ID;
					SET	ORDER_TOTAL_PAYMENT =_TOTAL_SUM;
					SET	AGE_COST = _ORDER_FEE;
						
					SET i=0;
		      SET TAGE_PROFIT_VALUE =0; 
					SET DLSFR =0;
					SET	DBF =_TELEGRAPH_FEE; 
					SET	SHCB = _TELEGRAPH_FEE*100+_ORDER_FEE;
					SET	XJFL =_MCHT_FEE;
					SET  XJCB =SHCB;
					SET ORDER_count =ORDER_count+1; 
					set i=true; 
						WHILE  i   DO  
					  SET edone = 0;
					  BEGIN
							
							DECLARE order_fee CURSOR FOR  select  AGE_ID,PAR_ID,AGE_NAME,AGE_FEE,AGE_MAX_FEE_VALUE,AGE_MIN_FEE_VALUE,AGE_FEE_CURRENCY,TELEGRAPH_FEE from v_remit_profit_fee where AGE_ID=ageId; 
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET edone = 1;
								OPEN order_fee;
								vfiledataLoop:LOOP 
									FETCH order_fee INTO _AGE_ID,_PAR_ID,_AGE_NAME,_AGE_FEE,_AGE_MAX_FEE_VALUE,_AGE_MIN_FEE_VALUE,_AGE_FEE_CURRENCY,_TELEGRAPH_FEE;		 
									IF edone = 1 THEN
										LEAVE vfiledataLoop;
									END IF;
						
				SET	DLSFR =ceil ( 
								CASE
										WHEN  ORDER_TOTAL_PAYMENT * _AGE_FEE /100  > _AGE_MAX_FEE_VALUE*100  THEN _AGE_MAX_FEE_VALUE*100  
										WHEN  ORDER_TOTAL_PAYMENT * _AGE_FEE /100  < _AGE_MIN_FEE_VALUE*100 THEN _AGE_MIN_FEE_VALUE*100  
										ELSE  ORDER_TOTAL_PAYMENT * _AGE_FEE /100  	END); 
					  SET TAGE_PROFIT_VALUE =TAGE_PROFIT_VALUE+DLSFR; 
					 
						SET	DLSDBF =_TELEGRAPH_FEE;
						  
								
								
						SET	AGE_PROFIT_VALUE =AGE_COST - DLSFR; 
							SET	AGE_COST=ceil ( CASE
										WHEN To_Number(ORDER_TOTAL_PAYMENT * _AGE_FEE)/100  >_AGE_MAX_FEE_VALUE*100   THEN
											_AGE_MAX_FEE_VALUE *100 
										WHEN To_Number(ORDER_TOTAL_PAYMENT * _AGE_FEE)/100  <_AGE_MIN_FEE_VALUE*100  THEN
											_AGE_MIN_FEE_VALUE *100 
										ELSE
											To_Number(ORDER_TOTAL_PAYMENT * _AGE_FEE)/100 
										END); 
							  
						SET		ageId=_PAR_ID; 
									if ageId  ='0000000000' THEN   
									SET	i=1;
									SET	AGE_PROFIT_VALUE =TDFR;
									SET	AGE_COST =0;
									end if;  
									
										SET	TDFR =AGE_COST;  
								
							  
									INSERT  INTO AMS_AGE_PROFIT_DETAILED
										(
											ORDER_ID,
											ORDER_PAY_DATE,
											ORDER_PAY_TIME,
											ORDER_TOTAL_PAYMENT,
											MCHT_ID,
											MCHT_NAME,
											MCHT_FEE,
											MCHT_MAX_FEE_VALUE,
											MCHT_MIN_FEE_VALUE,
											MCHT_COST,
											AGE_ID,
											AGE_NAME,
											AGE_FEE,
											AGE_MAX_FEE_VALUE,
											AGE_MIN_FEE_VALUE,
											AGE_COST,
											AGE_PROFIT_VALUE,
											CRT_OPR,
											CRT_TIME,
											AGE_PROFIT_DETAILED_ID,
								     	PROFIT_TYPE,
										  BILLING_METHOD,
											LOWER_FEE,
											LOWER_COST,
											AGE_TELEGRAPH_FEE,
											LOWER_TELEGRAPH_FEE
										) VALUES (
											_ORDER_ID, 
											SUBSTR(_REC_CRT_TS, 1, 8),
											SUBSTR(_REC_CRT_TS, 9, 6), 
											_TOTAL_SUM,
											_MCHT_NO,
											_MCHT_NAME,
											_MCHT_FEE,
											_MCHT_MAX_FEE_VALUE,
											_MCHT_MIN_FEE_VALUE,
											SHCB,
											_AGE_ID,
											_AGE_NAME,
											_AGE_FEE,
											_AGE_MAX_FEE_VALUE,
											_AGE_MIN_FEE_VALUE,
											AGE_COST+_TELEGRAPH_FEE*100,
											AGE_PROFIT_VALUE+ (DBF-_TELEGRAPH_FEE)*100,
											'0000000001',
												DATE_FORMAT( NOW(), '%Y%m%d%H%i%S' ) ,
											
											'02',
											0,
											XJFL,
											XJCB,
											DLSDBF,
											DBF
										);  
									SET	DBF =_TELEGRAPH_FEE; 
									SET	XJFL =_AGE_FEE;
									SET	XJCB =AGE_PROFIT_VALUE+DBF-_TELEGRAPH_FEE*100;
						 
								END LOOP vfiledataLoop; 
									CLOSE order_fee; 
								END;
				end WHILE;
				update AMS_OPR_ORDER_FILE_INFO set  PROFIT_STATE='0'  where ORDER_FILE_NUMBER=_ORDER_ID;
				end loop loop_a;
				CLOSE orderp;
select ORDER_count;
END;

