create
    definer = root@`%` procedure AMS_ORDER_STATISTICS(IN p_date varchar(16), IN p_opr varchar(225))
BEGIN
declare			_MCHT_ID 			INT; 
declare     _MCHT_NAME 							VARCHAR(32);	
declare     _TRADE_DATE 							VARCHAR(32);	
declare 		_DISPOSE_COUNT						VARCHAR(32);
declare 		_SUCCESS_COUNT						VARCHAR(32);
declare     _COU                    INT; 
declare 		_TOTAL_SUM						VARCHAR(32);
declare 		_SUCCCESS_SUM						VARCHAR(32);
declare 		_VALIDATION_FEE						VARCHAR(32);
declare 		_CUSTOMS_FEE						VARCHAR(32);
declare 		_TOTAL_VALIDATION_FEE						VARCHAR(32);
declare 		_TOTAL_CUSTOMS_FEE						VARCHAR(32);

DECLARE done INT DEFAULT FALSE;     
DECLARE orderp CURSOR FOR   
					select a.mcht_id,
           a.mcht_name,
           a.trade_date,
           sum(dispose_count) as dispose_count,
           sum(success_count) as success_count,
           count(*) as cou,
           sum(AMOUNT_PAID * 100) total_sum, 
           sum(IF(success_count= 1, AMOUNT_PAID * 100, 0)) as succcess_sum,
           SUM(IF(success_count= 1, VALIDATION_FEE, 0)) as VALIDATION_FEE,
           sum(IF(success_count=1, CUSTOMS_FEE, 0)) as CUSTOMS_FEE,
           sum(VALIDATION_FEE) as total_VALIDATION_FEE,
           sum(CUSTOMS_FEE) as total_CUSTOMS_FEE
      from (select a1.MCHT_ID as mcht_id,
                   a2.mcht_name,
                   substring(a1.APP_TIME, 1, 8) trade_date,
                   case
                     when RETURN_STATUS in ('0', '00', '000', '001','110','10086','1101','1102') then
                      1
                     else
                      0
                   end as dispose_count,
								 
                   case
                     when RETURN_STATUS in ('1', 'S', '03', '3', '2', '120') then
                      1
                     else
                      0
                   end as success_count,
                   IFNULL(VALIDATION_SERVICE_FEE, 0) as VALIDATION_FEE,
                   IFNULL(CUSTOMS_SERVICE_FEE, 0) as CUSTOMS_FEE,
                   AMOUNT_PAID
              from AMS_OPR_ORDER_RECORD a1
              Left join AMS_MCHT_BASE_INF a2
                on a1.mcht_id = a2.Mcht_Id
             where a1.APP_TIME >= CONCAT(p_date COLLATE utf8_unicode_ci,'000001')
               and a1.APP_TIME <= CONCAT(p_date COLLATE utf8_unicode_ci,'235959')) a
     group by a.mcht_id, a.mcht_name, a.trade_date limit 0,1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

		delete from AMS_OPR_ORDER_STATISTICS where TRADE_DATE = p_date COLLATE utf8_unicode_ci;
		
		OPEN orderp;
		
		loop_a:LOOP 
			
			FETCH orderp into   _MCHT_ID,_MCHT_NAME,_TRADE_DATE,_DISPOSE_COUNT,_SUCCESS_COUNT, _COU,_TOTAL_SUM,_SUCCCESS_SUM,_VALIDATION_FEE,_CUSTOMS_FEE,_TOTAL_VALIDATION_FEE,_TOTAL_CUSTOMS_FEE;
				
				if done=1 then
            leave loop_a;
        end if; 
		insert into AMS_OPR_ORDER_STATISTICS
      (MCHT_ID,
       MCHT_NM,
       TRADE_DATE,
       DISPOSE_COUNT,
       SUCCESS_COUNT,
       ERROR_COUNT,
       TOTAL_COUNT,
       SUCCESS_SUM,
       ERROR_SUM,
       TOTAL_SUM,
       CUSTOMS_FEE,
       VALIDATION_FEE,
       TOTAL_FEE_SUM,
       CRT_OPR_ID,
       REC_CRT_TS)
    values
      (LPAD(_MCHT_ID,10,'0'),
       _MCHT_NAME,
       _TRADE_DATE,
       _DISPOSE_COUNT,
       _SUCCESS_COUNT,
       _COU - _SUCCESS_COUNT - _DISPOSE_COUNT,
       _COU,
       _SUCCCESS_SUM,
       _TOTAL_SUM - _SUCCCESS_SUM,
       _TOTAL_SUM,
       _TOTAL_CUSTOMS_FEE,
       _TOTAL_VALIDATION_FEE,
       _TOTAL_VALIDATION_FEE +
       _TOTAL_CUSTOMS_FEE,
       p_opr,
       DATE_FORMAT( NOW(), '%Y%m%d%H%i%S' )); 
	
	END LOOP loop_a;
CLOSE orderp;
select p_opr;
 
END;

