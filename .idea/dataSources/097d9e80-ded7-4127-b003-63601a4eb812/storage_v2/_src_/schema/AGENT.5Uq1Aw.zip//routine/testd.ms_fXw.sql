create
    definer = root@`%` procedure testd(IN start_time varchar(16))
begin
  declare my_uname varchar(32) default '';
		declare 	  i          INT;  
		declare   	AGE_ID     VARCHAR(32);
		declare 	  AGE_NAME   VARCHAR(32);
		declare 		DLSFR      INT;
		declare 		DLSCB      INT;
		declare 		ageId      VARCHAR(32);  
		declare 		TDFR       INT; 
		declare 		ORDER_count INT;
		declare 		XJCB       INT;
		declare 		XJFL       INT;
		declare 		B_METHOD   INT;
		declare 		TDLSCB 	   INT;
		declare 		TDLSFR		 INT;
		declare 		TXJCB 		 INT; 

    
		DECLARE done INT DEFAULT FALSE;
		
		DECLARE ORDER_INFO_cursor CURSOR FOR 
				SELECT
				A2.AGE_ID,
				A2.MCHT_NAME,
				a1.*,
				a3.Fee_Max AS MCHT_MAX_FEE_VALUE,
				a3.Fee_Min AS MCHT_MIN_FEE_VALUE, 
				a3.fee AS MCHT_FEE,
				a3.BILLING_METHOD ,   
				a3.SINGLE_COST      
				FROM
				AMS_ACCOUNT_CONSUME_INF a1
				LEFT JOIN AMS_MCHT_BASE_INF a2 ON a1.MCHT_ID = A2.MCHT_ID
				INNER JOIN ams_opr_Fee a3 ON A2.Mcht_Id = a3.opr_ID  
			
			   where a1.PAY_date  = start_time  and  a3.TRADE_TYPE='03' and IFNULL(a1.PROFIT_STATE,'1')='1' ; 
			 
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

 
    set my_uname='linkui';  
		select ORDER_INFO_cursor;
  select my_uname,start_time; 
end;

