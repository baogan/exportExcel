create definer = root@`%` view V_AMS_ORDER_STATISTICS as
select `A`.`mcht_id`            AS `mcht_id`,
       `A`.`mcht_name`          AS `mcht_name`,
       `A`.`trade_date`         AS `trade_date`,
       sum(`A`.`dispose_count`) AS `dispose_count`,
       sum(`A`.`success_count`) AS `success_count`,
       count(0)                 AS `cou`,
       `A`.`success_sum`        AS `success_sum`
from `AGENT`.`V_AMS_ORDER_STATISTICS1` `A`
group by `A`.`mcht_id`, `A`.`mcht_name`, `A`.`trade_date`;

-- comment on column V_AMS_ORDER_STATISTICS.mcht_id not supported: 商户编号

-- comment on column V_AMS_ORDER_STATISTICS.mcht_name not supported: 企业名称

-- comment on column V_AMS_ORDER_STATISTICS.success_sum not supported: 支付金额

