create definer = root@`%` view v_remit_profit as
select `a1`.`MCHT_NO`           AS `MCHT_NO`,
       `a1`.`TOTAL_SUM`         AS `TOTAL_SUM`,
       `a1`.`REC_CRT_TS`        AS `REC_CRT_TS`,
       `a1`.`PAYMENT_DEAL_TIME` AS `PAYMENT_DEAL_TIME`,
       `a1`.`ORDER_FILE_NUMBER` AS `ORDER_ID`,
       `a1`.`FEE`               AS `ORDER_FEE`,
       `a2`.`AGE_ID`            AS `AGE_ID`,
       `a2`.`MCHT_NAME`         AS `Mcht_Name`,
       `a3`.`FEE_MAX`           AS `MCHT_MAX_FEE_VALUE`,
       `a3`.`FEE_MIN`           AS `MCHT_MIN_FEE_VALUE`,
       `a3`.`FEE`               AS `MCHT_FEE`,
       `a3`.`TELEGRAPH_FEE`     AS `TELEGRAPH_FEE`
from ((`AGENT`.`AMS_OPR_ORDER_FILE_INFO` `a1` left join `AGENT`.`AMS_MCHT_BASE_INF` `a2` on ((`a1`.`MCHT_NO` = `a2`.`MCHT_ID`)))
         left join `AGENT`.`AMS_OPR_FEE` `a3` on ((`a2`.`MCHT_ID` = `a3`.`OPR_ID`)))
where ((`a1`.`PROFIT_STATE` = '1') and (`a1`.`ORDER_STATUS` = '3') and
       (`a1`.`PAYMENT_STATUS` = '1') and (`a1`.`RECORD_STATUS` = '0') and (`a3`.`TRADE_TYPE` = 2));

-- comment on column v_remit_profit.MCHT_NO not supported: 商户编号

-- comment on column v_remit_profit.TOTAL_SUM not supported: 订单明细总额

-- comment on column v_remit_profit.REC_CRT_TS not supported: 创建时间

-- comment on column v_remit_profit.PAYMENT_DEAL_TIME not supported: 付款银行处理时间

-- comment on column v_remit_profit.ORDER_ID not supported: 订单文件编号

-- comment on column v_remit_profit.ORDER_FEE not supported: 手续费

-- comment on column v_remit_profit.AGE_ID not supported: 商户所属代理商编号

-- comment on column v_remit_profit.Mcht_Name not supported: 企业名称

-- comment on column v_remit_profit.MCHT_MAX_FEE_VALUE not supported: 封顶手续费

-- comment on column v_remit_profit.MCHT_MIN_FEE_VALUE not supported: 保底费用

-- comment on column v_remit_profit.MCHT_FEE not supported: 费率(%)

-- comment on column v_remit_profit.TELEGRAPH_FEE not supported: 电报费

