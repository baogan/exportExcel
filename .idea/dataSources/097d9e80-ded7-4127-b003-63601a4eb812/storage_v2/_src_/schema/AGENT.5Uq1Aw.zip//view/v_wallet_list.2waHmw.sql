create definer = root@`%` view v_wallet_list as
select `A1`.`T_TYPE`       AS `T_TYPE`,
       (`A1`.`AMOUNT` * 1) AS `AMOUNT`,
       `A1`.`BILL_ID`      AS `BILL_ID`,
       `A3`.`AGE_ID`       AS `AGE_ID`,
       `A1`.`RECORD_DATE`  AS `RECORD_DATE`,
       `A1`.`RECORD_TIME`  AS `RECORD_TIME`,
       `A3`.`MCHT_ID`      AS `MCHT_ID`,
       `A3`.`MCHT_NAME`    AS `MCHT_NAME`
from ((`AGENT`.`v_wallet_record` `A1` left join `AGENT`.`AMS_OPR_FEE` `A2` on ((
        (`A1`.`T_TYPE` = `A2`.`TRADE_NAME`) and (`A1`.`OPR_ID` = `A2`.`OPR_ID`))))
         left join `AGENT`.`AMS_MCHT_BASE_INF` `A3` on ((`A2`.`OPR_ID` = `A3`.`MCHT_ID`)))
where ((`A1`.`RECORD_TYPE` = 0) and (`A1`.`TRADE_TYPE` = 0));

-- comment on column v_wallet_list.BILL_ID not supported: 订单号

-- comment on column v_wallet_list.AGE_ID not supported: 商户所属代理商编号

-- comment on column v_wallet_list.RECORD_DATE not supported: 日期

-- comment on column v_wallet_list.RECORD_TIME not supported: 时间

-- comment on column v_wallet_list.MCHT_ID not supported: 商户编号

-- comment on column v_wallet_list.MCHT_NAME not supported: 企业名称

