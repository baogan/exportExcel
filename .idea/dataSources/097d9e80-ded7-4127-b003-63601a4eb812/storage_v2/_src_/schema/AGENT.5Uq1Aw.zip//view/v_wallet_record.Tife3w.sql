create definer = root@`%` view v_wallet_record as
select (case
            when (`AGENT`.`AMS_WALLET_RECORD`.`TRADE_NAME` = '海关推单') then '04'
            when (`AGENT`.`AMS_WALLET_RECORD`.`TRADE_NAME` = '二要素鉴权服务') then '041'
            else '0' end)                        AS `T_TYPE`,
       `AGENT`.`AMS_WALLET_RECORD`.`OPR_ID`      AS `OPR_ID`,
       `AGENT`.`AMS_WALLET_RECORD`.`AMOUNT`      AS `AMOUNT`,
       `AGENT`.`AMS_WALLET_RECORD`.`BILL_ID`     AS `BILL_ID`,
       `AGENT`.`AMS_WALLET_RECORD`.`RECORD_DATE` AS `RECORD_DATE`,
       `AGENT`.`AMS_WALLET_RECORD`.`RECORD_TIME` AS `RECORD_TIME`,
       `AGENT`.`AMS_WALLET_RECORD`.`TRADE_TYPE`  AS `TRADE_TYPE`,
       `AGENT`.`AMS_WALLET_RECORD`.`RECORD_TYPE` AS `RECORD_TYPE`
from `AGENT`.`AMS_WALLET_RECORD`;

-- comment on column v_wallet_record.OPR_ID not supported: 操作员ID

-- comment on column v_wallet_record.AMOUNT not supported: 交易金额(分)

-- comment on column v_wallet_record.BILL_ID not supported: 订单号

-- comment on column v_wallet_record.RECORD_DATE not supported: 日期

-- comment on column v_wallet_record.RECORD_TIME not supported: 时间

-- comment on column v_wallet_record.TRADE_TYPE not supported: 交易类型 
0-扣款 
1-充值
2-调账加
3-调账减

-- comment on column v_wallet_record.RECORD_TYPE not supported: 记录类型 0 手续费钱包 1 积分 2 商户账户钱包

