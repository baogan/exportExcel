create
    definer = root@`%` function queryChildrenAreaInfo(areaId varchar(10)) returns varchar(4000)
BEGIN
DECLARE sTemp VARCHAR(4000);
DECLARE sTempChd VARCHAR(4000);

SET sTemp='$';
SET sTempChd = CAST(areaId AS CHAR);

WHILE sTempChd IS NOT NULL DO
SET sTemp= CONCAT(sTemp,',',sTempChd);
SELECT GROUP_CONCAT(OPR_ID) INTO sTempChd FROM MMS_OPR_OPR_INF WHERE FIND_IN_SET(CRT_OPR,sTempChd)>0;
END WHILE;
RETURN sTemp;
END;

