create
    definer = root@`%` procedure dome1(IN start_time varchar(32), IN end_time varchar(32))
begin 
declare		  ORDER_NOS  							VARCHAR(225); 
DECLARE				 i 									INT DEFAULT TRUE;
declare		  ageId  									VARCHAR(32);  
declare		  ORDER_count 						INT;
declare			AGE_IDm 		  						VARCHAR(32); 
declare     AGE_ID                  VARCHAR(32);
declare			AGE_NAME    						VARCHAR(32); 
declare			RTS         						VARCHAR(32); 
declare			AGE_COST	  						INT; 
declare			LOWER_COST 							INT; 
declare			AGE_PROFIT_VALUE				INT; 
declare			R_AGE_COST							INT; 
declare			R_LOWER_COST 						INT; 
declare			R_AGE_PROFIT_VALUE 			INT; 
declare     MCHT_NAMEm 							VARCHAR(32);
declare     MCHT_IDm    							VARCHAR(12);
declare     MESSAGE_IDm  						VARCHAR(225);
declare			APP_TIMEm   							VARCHAR(20);
declare			ORDER_NOm   							VARCHAR(64);
declare			AMOUNT_PAIDm  						DOUBLE(19,5);
declare 		PAY_TIMEm   							VARCHAR(14);
declare			RETURN_STATUSm 					VARCHAR(10);
declare     VALIDATION_SERVICE_FEEm	VARCHAR(10);
declare			CUSTOMS_SERVICE_FEEm 		VARCHAR(10);
declare 		PROFIT_STATEm 						VARCHAR(10); 
declare      AGE_IDf                    VARCHAR(10);
declare      PAR_IDf                    VARCHAR(10);
declare      AGE_NAMEf                  VARCHAR(10);
declare      TRADE_NAMEf                VARCHAR(10);
declare      SINGLE_COSTf               VARCHAR(10);
declare      BILLING_METHODf            VARCHAR(10);
declare      FEEf                       VARCHAR(10);
declare      FEE_MINf                   VARCHAR(10);
declare      FEE_MAXf                   VARCHAR(10);
 DECLARE done INT DEFAULT 0;     
DECLARE donef INT DEFAULT 0;      

 

		DECLARE orderp CURSOR FOR   
						select AGE_ID,MCHT_NAME,MCHT_ID,MESSAGE_ID,
									 APP_TIME,ORDER_NO,AMOUNT_PAID,PAY_TIME,RETURN_STATUS,
									 VALIDATION_SERVICE_FEE,CUSTOMS_SERVICE_FEE,PROFIT_STATE
								 	from	v_order_record LIMIT 5; 
 DECLARE order_fee CURSOR FOR   select AGE_ID,PAR_ID,AGE_NAME,TRADE_NAME,SINGLE_COST,BILLING_METHOD,FEE,FEE_MIN,FEE_MAX from v_order_record_fee where AGE_ID=ageId; 
					DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; 
				   SET 	ORDER_count =0;
						SET 	AGE_COST =0;
						set R_AGE_PROFIT_VALUE=0;		
			
	OPEN orderp; 
						orderp_loop: LOOP
							FETCH NEXT FROM  orderp into AGE_IDm,MCHT_NAMEm,MCHT_IDm,MESSAGE_IDm,APP_TIMEm,ORDER_NOm,AMOUNT_PAIDm, PAY_TIMEm,RETURN_STATUSm,VALIDATION_SERVICE_FEEm,CUSTOMS_SERVICE_FEEm,PROFIT_STATEm;
							IF done=1 THEN
								LEAVE orderp_loop;
							END IF;    
										SET 	ORDER_count =ORDER_count+1; 
										
 
										OPEN order_fee; 	
												of_loop:LOOP
													FETCH NEXT FROM order_fee INTO AGE_IDf,PAR_IDf,AGE_NAMEf,TRADE_NAMEf,SINGLE_COSTf,BILLING_METHODf,FEEf,FEE_MINf,FEE_MAXf;	
												
							
													set AGE_COST=AGE_COST+1;
													set R_AGE_PROFIT_VALUE=R_AGE_PROFIT_VALUE+1;		 
								 
											END LOOP of_loop;
								CLOSE order_fee;
								
							 SET done = 0;  

		
	END LOOP orderp_loop;
	CLOSE orderp;
select ORDER_count,R_AGE_PROFIT_VALUE;
END;

