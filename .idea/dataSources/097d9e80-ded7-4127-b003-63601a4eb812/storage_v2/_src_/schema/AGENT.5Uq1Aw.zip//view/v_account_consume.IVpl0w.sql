create definer = root@`%` view v_account_consume as
select `a2`.`AGE_ID`          AS `AGE_ID`,
       `a2`.`MCHT_NAME`       AS `MCHT_NAME`,
       `a1`.`ORDER_NO`        AS `ORDER_NO`,
       `a1`.`MCHT_ID`         AS `MCHT_ID`,
       `a1`.`CUSTOM_ID`       AS `CUSTOM_ID`,
       `a1`.`PAY_DATE`        AS `PAY_DATE`,
       `a1`.`PAY_TIME`        AS `PAY_TIME`,
       `a1`.`PAY_AMT`         AS `PAY_AMT`,
       `a1`.`ORDER_FEE_VALUE` AS `ORDER_FEE_VALUE`,
       `a1`.`PROFIT_STATE`    AS `PROFIT_STATE`,
       `a3`.`FEE_MAX`         AS `MCHT_MAX_FEE_VALUE`,
       `a3`.`FEE_MIN`         AS `MCHT_MIN_FEE_VALUE`,
       `a3`.`FEE`             AS `MCHT_FEE`,
       `a3`.`BILLING_METHOD`  AS `BILLING_METHOD`,
       `a3`.`SINGLE_COST`     AS `SINGLE_COST`
from ((`AGENT`.`AMS_ACCOUNT_CONSUME_INF` `a1` left join `AGENT`.`AMS_MCHT_BASE_INF` `a2` on ((`a1`.`MCHT_ID` = `a2`.`MCHT_ID`)))
         join `AGENT`.`AMS_OPR_FEE` `a3` on ((`a2`.`MCHT_ID` = `a3`.`OPR_ID`)))
where ((`a3`.`TRADE_TYPE` = '03') and (ifnull(`a1`.`PROFIT_STATE`, '1') = '1'));

-- comment on column v_account_consume.AGE_ID not supported: 商户所属代理商编号

-- comment on column v_account_consume.MCHT_NAME not supported: 企业名称

-- comment on column v_account_consume.ORDER_NO not supported: 支付订单号（唯一）订单号83+商户号+年月日时分秒+6随机数

-- comment on column v_account_consume.MCHT_ID not supported: 商户编号

-- comment on column v_account_consume.CUSTOM_ID not supported: 客户编号

-- comment on column v_account_consume.PAY_DATE not supported: 支付日期

-- comment on column v_account_consume.PAY_TIME not supported: 支付时间

-- comment on column v_account_consume.PAY_AMT not supported: 消费金额 单位分

-- comment on column v_account_consume.ORDER_FEE_VALUE not supported: 手续费

-- comment on column v_account_consume.PROFIT_STATE not supported: 分润状态 0已计算 1未计算

-- comment on column v_account_consume.MCHT_MAX_FEE_VALUE not supported: 封顶手续费

-- comment on column v_account_consume.MCHT_MIN_FEE_VALUE not supported: 保底费用

-- comment on column v_account_consume.MCHT_FEE not supported: 费率(%)

-- comment on column v_account_consume.BILLING_METHOD not supported: 计费方式 0-按费率 1-按单笔

-- comment on column v_account_consume.SINGLE_COST not supported: 单笔费用

